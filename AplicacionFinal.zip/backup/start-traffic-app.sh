#!/bin/sh
set -e

# Ejecuta el backend del sistema de tráfico (SIN GUI)
cd /opt/traffic-app

# PEOPLE CAM
python3 -u people_counter_cam.py \
    --src 0 \
    --yolo_model yolov5n.onnx \
    --write_count /tmp/ped_count.txt \
    --flag_out /tmp/ped_flag.txt &

# VEH CAM
python3 -u veh_counter_cam.py \
    --src 2 \
    --yolo_model yolov5n.onnx \
    --write_count /tmp/veh_moving.txt \
    --flag_out /tmp/veh_flag.txt \
    --animal_flag_out /tmp/animal_flag.txt &

# CONTROLLER (proceso principal)
exec python3 -u traffic_control.py

