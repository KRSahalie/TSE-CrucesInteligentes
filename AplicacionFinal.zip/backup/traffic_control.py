#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ==================================================================================================
#                                 TRAFFIC CONTROL SYSTEM (Raspberry-Ready)
# ==================================================================================================
# - Controlador robusto de semáforos con manejo de peatones, vehículos y animales.
# - Incluye bloqueos de 1000s por animales, cooldowns, post-event red, y salida estable.
# - Diseñado para integrarse con tu GUI que parsea estados CAR_STATE / PEA_PASS.
# ==================================================================================================

import time
import logging
import os


# ---------------------------- LOGGING CONFIG ---------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s\t%(levelname)s\t%(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# ---------------------------- FLAG FILES -------------------------------------
PED_FLAG_FILE    = "/tmp/ped_flag.txt"
VEH_FLAG_FILE    = "/tmp/veh_flag.txt"
ANIMAL_FLAG_FILE = "/tmp/animal_flag.txt"


# ---------------------------- CONSTANTS --------------------------------------
CAR_GREEN = "VERDE"
CAR_AMBER = "AMARILLO"
CAR_RED   = "ROJO"

PEA_GREEN = "VERDE"
PEA_RED   = "ROJO"

# Duraciones grandes (tu configuración)
DUR_GREEN        = 30
DUR_AMBER        = 2
DUR_RED          = 15
DUR_PEDESTRIAN   = 20
DUR_COOLDOWN     = 25
DUR_POST_EVENT_RED = 1   # 1 segundo de transición rojo


# ---------------------------- STATE VARIABLES --------------------------------
car_state  = CAR_GREEN
pea_state  = PEA_RED

animal_active      = False
pedestrian_active  = False
pedestrian_cooldown = 0.0
phase_end_time      = 0.0
is_post_event_red   = False


# ---------------------------- LOG STATE CHANGES ------------------------------
def log_state_change(new_car, new_pea, duration, tag, reason=""):
    global car_state, pea_state, phase_end_time

    if car_state != new_car or pea_state != new_pea:
        car_state = new_car
        pea_state = new_pea

        if duration is not None:
            phase_end_time = time.time() + duration

        logging.info(f"{tag}\t{car_state}\t{pea_state}\t{reason}")
        return True

    return False


# ---------------------------- READ FLAG --------------------------------------
def read_flag(path):
    try:
        if os.path.exists(path):
            with open(path, "r") as f:
                return f.read().strip() == "1"
    except:
        pass
    return False


# ---------------------------- COOL DOWNS --------------------------------------
def update_cooldowns():
    global pedestrian_cooldown
    if pedestrian_cooldown > 0 and not pedestrian_active:
        pedestrian_cooldown -= 0.1


# ---------------------------- PHASE HELPERS -----------------------------------
def reset_car_cycle_to_green():
    global phase_end_time, is_post_event_red, pedestrian_cooldown

    if not animal_active and not pedestrian_active:

        changed = log_state_change(
            CAR_RED, PEA_RED, DUR_POST_EVENT_RED,
            "CAR_STATE",
            f"Transicion a rojo despues de evento ({DUR_POST_EVENT_RED}s)"
        )

        if not changed and car_state == CAR_RED and pea_state == PEA_RED:
            phase_end_time = time.time() + DUR_POST_EVENT_RED
            logging.info(
                f"CAR_STATE\t{car_state}\t{pea_state}\tReiniciando temporizador a ROJO de transicion (1s)"
            )
            changed = True

        if changed:
            is_post_event_red = True
            pedestrian_cooldown = DUR_POST_EVENT_RED + 1
            logging.info(
                f"COOLDOWN_SET\t{car_state}\t{pea_state}\tCooldown de seguridad {pedestrian_cooldown}s"
            )
            return True

    return False


def start_pedestrian_phase():
    return log_state_change(
        CAR_RED, PEA_GREEN,
        DUR_PEDESTRIAN,
        "PEA_PASS",
        f"Peaton en verde por {DUR_PEDESTRIAN}s"
    )


# ---------------------------- ANIMAL EVENT ------------------------------------
def start_animal_event():
    global animal_active, is_post_event_red

    if not animal_active:
        logging.warning(f"ANIMAL_DETECT\t{car_state}\t{pea_state}\tAnimal detectado.")
        animal_active = True
        is_post_event_red = False

        if car_state == CAR_GREEN:
            return log_state_change(
                CAR_AMBER, PEA_RED, DUR_AMBER,
                "CAR_STATE", "Transicion a ambar por animal"
            )

        log_state_change(
            CAR_RED, PEA_RED, 1000,
            "CAR_STATE",
            "Animal en zona de cruce. Bloqueo manual."
        )
        return True

    return False


def end_animal_event():
    global animal_active
    if animal_active:
        logging.info(f"ANIMAL_END\t{car_state}\t{pea_state}\tAnimal ya no está.")
        animal_active = False
        return reset_car_cycle_to_green()


# ---------------------------- PEDESTRIAN EVENT --------------------------------
def start_pedestrian_event():
    global pedestrian_active

    if (
        not pedestrian_active
        and pedestrian_cooldown <= 0
        and not is_post_event_red
    ):
        logging.info(f"PEA_REQUEST\t{car_state}\t{pea_state}\tPeaton en espera.")
        pedestrian_active = True

        if car_state == CAR_GREEN:
            return log_state_change(
                CAR_AMBER, PEA_RED, DUR_AMBER,
                "CAR_STATE", "Transicion a ambar por peaton"
            )

        elif car_state == CAR_AMBER:
            return log_state_change(
                CAR_RED, PEA_RED, 0.1,
                "CAR_STATE", "Forzando rojo por peaton"
            )

        else:
            return start_pedestrian_phase()

    return False


def end_pedestrian_event():
    global pedestrian_active, pedestrian_cooldown

    logging.info(f"PEA_END\t{car_state}\t{pea_state}\tFase peatonal terminada.")
    pedestrian_active = False
    pedestrian_cooldown = DUR_COOLDOWN
    return reset_car_cycle_to_green()


# ---------------------------- MAIN LOOP ----------------------------------------
try:
    log_state_change(CAR_GREEN, PEA_RED, DUR_GREEN,
                     "SYSTEM_INIT",
                     "Control iniciado. VERDE coches / ROJO peatones.")

    while True:
        now = time.time()
        update_cooldowns()

        animal_flag = read_flag(ANIMAL_FLAG_FILE)
        ped_flag    = read_flag(PED_FLAG_FILE)

        # ---------------------- POST EVENT 1s RED -------------------------
        if is_post_event_red and car_state == CAR_RED:
            if now >= phase_end_time:
                if log_state_change(
                        CAR_GREEN, PEA_RED,
                        DUR_GREEN,
                        "CAR_STATE",
                        "Fin de rojo transicion. Ciclo normal."):
                    is_post_event_red = False
                    continue
            else:
                time.sleep(0.1)
                continue

        # ---------------------- ANIMAL PRIORITY ---------------------------
        if animal_flag and not animal_active:
            if start_animal_event():
                continue

        elif animal_active and not animal_flag:
            if end_animal_event():
                continue

        # ---------------------- ACTIVE EVENTS ------------------------------
        if animal_active or pedestrian_active:

            # FIX: si quedó pegado en CAR_RED/PEA_RED sin animal y con peaton activo
            if (pedestrian_active and not animal_active 
                and car_state == CAR_RED and pea_state == PEA_RED):
                if start_pedestrian_phase():
                    continue

            if car_state == CAR_AMBER and now >= phase_end_time:
                if pedestrian_active:
                    start_pedestrian_phase()
                    continue
                elif animal_active:
                    log_state_change(
                        CAR_RED, PEA_RED, 1000,
                        "CAR_STATE",
                        "Animal en cruce. Bloqueo manual.")
                    continue

            elif pea_state == PEA_GREEN and now >= phase_end_time and pedestrian_active:
                end_pedestrian_event()
                continue

        # ---------------------- NORMAL PEDESTRIAN EVENT -------------------
        elif ped_flag and not animal_active and not pedestrian_active and pedestrian_cooldown <= 0 and not is_post_event_red:
            if start_pedestrian_event():
                continue

        # ---------------------- NORMAL CYCLE -------------------------------
        elif not animal_active and not pedestrian_active and not is_post_event_red:

            if car_state == CAR_GREEN and now >= phase_end_time:
                if log_state_change(
                        CAR_AMBER, PEA_RED, DUR_AMBER,
                        "CAR_STATE", "Ciclo normal a ambar"):
                    continue

            elif car_state == CAR_AMBER and now >= phase_end_time:
                if log_state_change(
                        CAR_RED, PEA_RED, DUR_RED,
                        "CAR_STATE", "Ciclo normal a rojo"):
                    continue

            elif car_state == CAR_RED and pea_state == PEA_RED and now >= phase_end_time:
                if log_state_change(
                        CAR_RED, PEA_GREEN, DUR_PEDESTRIAN,
                        "PEA_PASS", "Ciclo normal a verde peatonal"):
                    continue

            elif car_state == CAR_RED and pea_state == PEA_GREEN and now >= phase_end_time:
                if log_state_change(
                        CAR_GREEN, PEA_RED, DUR_GREEN,
                        "CAR_STATE", "Ciclo normal a verde"):
                    continue

        time.sleep(0.1)

except KeyboardInterrupt:
    logging.warning(f"SYSTEM_SHUTDOWN\t{car_state}\t{pea_state}\tApagado manual (CTRL+C)")

except Exception as e:
    logging.error(f"SYSTEM_ERROR\t{car_state}\t{pea_state}\tError critico: {e}")
