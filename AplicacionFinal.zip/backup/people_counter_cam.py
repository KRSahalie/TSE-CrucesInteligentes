#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ==================================================================================================
#  PeatonCam — YOLOv5n ONNX (OpenCV DNN) — Raspberry Pi / Yocto compatible
# ==================================================================================================

from __future__ import annotations
import os, cv2, time, json, argparse
import numpy as np

COLOR = {
    "persona": (60,180,255),
    "animal": (255,120,120),
    None: (220,220,220)
}

def draw_box(frame, xyxy, label=None, conf=None):
    x1,y1,x2,y2 = [int(v) for v in xyxy]
    color = COLOR.get(label, (220,220,220))
    cv2.rectangle(frame,(x1,y1),(x2,y2),color,2)
    txt = []
    if label: txt.append(label)
    if conf is not None: txt.append(f"{conf:.2f}")
    if txt:
        t = " | ".join(txt)
        (tw,th),_ = cv2.getTextSize(t, cv2.FONT_HERSHEY_SIMPLEX,0.5,1)
        cv2.rectangle(frame,(x1,y1-th-6),(x1+tw+6,y1),color,-1)
        cv2.putText(frame,t,(x1+3,y1-4),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,0,0),1)


# ==================================================================================================
#  YOLO — FORMATO CORRECTO (25200, 85)
# ==================================================================================================
class YOLODetector:
    def __init__(self, model_path="yolov5n.onnx", conf=0.5, imgsz=640, nms_iou=0.60):
        self.net = cv2.dnn.readNetFromONNX(model_path)
        self.conf = float(conf)
        self.imgsz = imgsz
        self.nms_iou = nms_iou

        # COCO
        self.names = [
            "person","bicycle","car","motorcycle","airplane","bus","train","truck","boat",
            "traffic light","fire hydrant","stop sign","parking meter","bench","bird","cat","dog",
            "horse","sheep","cow","elephant","bear","zebra","giraffe","backpack","umbrella",
            "handbag","tie","suitcase","frisbee","skis","snowboard","sports ball","kite",
            "baseball bat","baseball glove","skateboard","surfboard","tennis racket","bottle",
            "wine glass","cup","fork","knife","spoon","bowl","banana","apple","sandwich","orange",
            "broccoli","carrot","hot dog","pizza","donut","cake","chair","couch","potted plant",
            "bed","dining table","toilet","tv","laptop","mouse","remote","keyboard","cell phone",
            "microwave","oven","toaster","sink","refrigerator","book","clock","vase","scissors",
            "teddy bear","hair drier","toothbrush"
        ]

    def infer(self, frame):
        H, W = frame.shape[:2]

        blob = cv2.dnn.blobFromImage(
            frame, 1/255.0, (self.imgsz, self.imgsz),
            swapRB=True, crop=False
        )
        self.net.setInput(blob)

        # salida correcta: (25200, 85)
        out = self.net.forward()[0]

        boxes = []
        labels = []
        confs = []

        for det in out:
            obj_conf = det[4]
            cls_scores = det[5:]
            cls_id = int(np.argmax(cls_scores))
            cls_conf = cls_scores[cls_id]
            conf = float(obj_conf * cls_conf)

            if conf < self.conf:
                continue

            cls_name = self.names[cls_id].lower()

            # mapear animales → persona si querés
            if cls_name in {"person", "bird", "cat", "horse", "sheep", "cow"}:
                label = "persona"
            else:
                continue

            cx, cy, w, h = det[0], det[1], det[2], det[3]

            x1 = (cx - w/2) * (W / self.imgsz)
            y1 = (cy - h/2) * (H / self.imgsz)
            x2 = (cx + w/2) * (W / self.imgsz)
            y2 = (cy + h/2) * (H / self.imgsz)

            boxes.append([x1, y1, x2, y2])
            labels.append(label)
            confs.append(conf)

        # -------------------------
        # 🔥 NMS CORREGIDO
        # -------------------------
        if boxes:
            nms_boxes = []
            for b in boxes:
                x1, y1, x2, y2 = b
                nms_boxes.append([
                    x1,
                    y1,
                    x2 - x1,
                    y2 - y1
                ])

            idxs = cv2.dnn.NMSBoxes(nms_boxes, confs, self.conf, self.nms_iou)

            if len(idxs) > 0:
                idxs = idxs.flatten().tolist()
                boxes  = [boxes[i] for i in idxs]
                labels = [labels[i] for i in idxs]
                confs  = [confs[i] for i in idxs]

        return boxes, labels, confs


# ==================================================================================================
#  MAIN
# ==================================================================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--display", action="store_true")
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--yolo_model", default="yolov5n.onnx")
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--ped_conf", type=float, default=0.20)
    ap.add_argument("--write_count")
    ap.add_argument("--flag_out")
    ap.add_argument("--flag_threshold", type=int, default=5)

    args = ap.parse_args()

    yolo = YOLODetector(
        model_path=args.yolo_model,
        conf=args.ped_conf,
        imgsz=args.imgsz
    )

    src = int(args.src) if args.src.isdigit() else args.src
    cap = cv2.VideoCapture(src)

    if not cap.isOpened():
        print("[PeatonCam] ERROR: Cámara no disponible", flush=True)
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    cap.set(cv2.CAP_PROP_FPS, args.fps)

    if args.display:
        cv2.namedWindow("PeatonCam", cv2.WINDOW_NORMAL)

    last_flag = None

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break

            frame = cv2.resize(frame, (args.width, args.height))

            boxes, labels, confs = yolo.infer(frame)
            persons = [b for b,l in zip(boxes, labels) if l == "persona"]

            count = len(persons)
            print(json.dumps({"ts": time.time(), "persons": count}), flush=True)

            if args.write_count:
                open(args.write_count, "w").write(str(count))

            if args.flag_out:
                flag = 1 if count >= args.flag_threshold else 0
                if flag != last_flag:
                    open(args.flag_out,"w").write(str(flag))
                    last_flag = flag

            if args.display:
                vis = frame.copy()
                for b,c in zip(persons, confs):
                    draw_box(vis, b, "persona", c)
                cv2.imshow("PeatonCam", vis)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break

    except KeyboardInterrupt:
        pass

    cap.release()
    if args.display:
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

