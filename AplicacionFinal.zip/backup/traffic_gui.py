#!/usr/bin/env python3
# traffic_gui.py
# GUI que arranca/monitoriza PeopleCam, VehCam y TrafficController
# Raspberry/Yocto compatible – corre procesos sin buffer (-u)

import tkinter as tk
from tkinter import scrolledtext, ttk, messagebox
import subprocess
import threading
import queue
import os
import signal
import time
import sys

# Python executable (Raspberry safe)
PY = sys.executable

# ---------------- CONFIG ----------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

PEOPLE_SCRIPT = os.path.join(BASE_DIR, "people_counter_cam.py")
VEH_SCRIPT   = os.path.join(BASE_DIR, "veh_counter_cam.py")
CTRL_SCRIPT  = os.path.join(BASE_DIR, "traffic_control.py")

MODEL_PATH   = os.path.join(BASE_DIR, "yolov5n.onnx")  # <-- asegúrate que el modelo esté aquí


PED_COUNT_FILE   = "/tmp/ped_count.txt"
PED_FLAG_FILE    = "/tmp/ped_flag.txt"
VEH_COUNT_FILE   = "/tmp/veh_moving.txt"
VEH_FLAG_FILE    = "/tmp/veh_flag.txt"
ANIMAL_FLAG_FILE = "/tmp/animal_flag.txt"

# ---------------- GUI / runtime state ----------------
root = tk.Tk()
root.title("Traffic System GUI (Live Logs + Semaphores)")
root.geometry("1250x820")

_processes = {"people": None, "veh": None, "ctrl": None}
_queues = {"people": queue.Queue(), "veh": queue.Queue(), "ctrl": queue.Queue()}
_lock = threading.Lock()

veh_state = "RED"
ped_state = "RED"

# Colors
RED_COLOR = "#c0392b"
AMBER_COLOR = "#f39c12"
GREEN_COLOR = "#27ae60"
GRAY_COLOR = "#7f8c8d"

# Button style
style = ttk.Style()
style.configure('Accent.TButton', foreground='white', background=GREEN_COLOR, font=('TkDefaultFont', 10, 'bold'))
style.map('Accent.TButton', background=[('active', GREEN_COLOR)])

# ---------------- Helpers ----------------
def start_process(name, cmd_list):
    with _lock:
        p = _processes.get(name)
        if p is not None and p.poll() is None:
            append_log(name, f"[GUI] {name} ya se está ejecutando (pid {p.pid})")
            return

        try:
            proc = subprocess.Popen(
                cmd_list,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                preexec_fn=os.setsid
            )
            _processes[name] = proc
            append_log(name, f"[GUI] iniciado {name} (pid {proc.pid})")

            threading.Thread(target=_reader_thread, args=(name, proc), daemon=True).start()

        except Exception as e:
            append_log(name, f"[GUI] error al iniciar {name}: {e}")

def stop_process(name):
    with _lock:
        p = _processes.get(name)
        if p is None:
            append_log(name, f"[GUI] {name} no se está ejecutando")
            return
        if p.poll() is not None:
            append_log(name, f"[GUI] {name} ya ha salido (rc {p.returncode})")
            _processes[name] = None
            return

        try:
            os.killpg(os.getpgid(p.pid), signal.SIGINT)
        except:
            try: p.terminate()
            except: pass

        try:
            p.wait(timeout=3)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(os.getpgid(p.pid), signal.SIGKILL)
            except:
                try: p.kill()
                except: pass

        append_log(name, f"[GUI] detenido {name} (rc {p.poll()})")
        _processes[name] = None

def stop_all_processes():
    for n in ["ctrl", "veh", "people"]:
        stop_process(n)

# ---------------- Process start functions ----------------
def start_people():
    cmd = [PY, "-u", PEOPLE_SCRIPT,
           "--src", "2", "--display",
           "--yolo_model", MODEL_PATH,          # <--- AQUÍ
           "--write_count", PED_COUNT_FILE,
           "--flag_out", PED_FLAG_FILE]
    start_process("people", cmd)

def start_veh():
    cmd = [PY, "-u", VEH_SCRIPT,
           "--src", "0", "--display",
           "--yolo_model", MODEL_PATH,          # <--- AQUÍ
           "--write_count", VEH_COUNT_FILE,
           "--flag_out", VEH_FLAG_FILE,
           "--animal_flag_out", ANIMAL_FLAG_FILE]
    start_process("veh", cmd)

def start_ctrl():
    cmd = [PY, "-u", CTRL_SCRIPT]
    start_process("ctrl", cmd)

def start_all_processes():
    stop_all_processes()
    root.after(100, start_people)
    root.after(500, start_veh)
    root.after(1000, start_ctrl)

# ---------------- Reader thread ----------------
def _reader_thread(name, proc):
    q = _queues[name]
    try:
        while True:
            line = proc.stdout.readline()
            if line == "" and proc.poll() is not None:
                break
            if not line:
                time.sleep(0.01)
                continue

            text = line.rstrip("\n")
            q.put(text)

            if name == "ctrl":
                parse_and_apply_ctrl_line(text)

    except Exception as e:
        q.put(f"[GUI] error en hilo lector: {e}")

    finally:
        q.put(f"[GUI] proceso terminado (rc {proc.poll()})")

# ---------------- Log parsing ----------------
def parse_and_apply_ctrl_line(line: str):
    global veh_state, ped_state

    L = line.upper()

    if any(k in L for k in ["CAR_STATE","PEA_PASS","PEA_END","ANIMAL_DETECT","ANIMAL_END"]):
        words = L.split()
        try:
            idx = next(i for i,w in enumerate(words)
                       if w in ["CAR_STATE","PEA_PASS","ANIMAL_DETECT","ANIMAL_END","PEA_REQUEST","PEA_END"])
        except StopIteration:
            return

        if len(words) > idx + 2:
            car_s = words[idx+1]
            pea_s = words[idx+2]

            veh_state = (
                "GREEN" if "VERDE" in car_s else
                "AMBER" if "AMARILLO" in car_s or "AMBER" in car_s else
                "RED"
            )

            ped_state = (
                "GREEN" if "VERDE" in pea_s else
                "RED"
            )

# ---------------- Log window refresh ----------------
def append_log(name, text):
    _queues[name].put(str(text))

def drain_queues_to_widgets():
    changed = False

    for name, q in _queues.items():
        widget = {"people": people_log, "veh": veh_log, "ctrl": ctrl_log}[name]
        while True:
            try:
                line = q.get_nowait()
            except queue.Empty:
                break
            widget.configure(state="normal")
            widget.insert(tk.END, line + "\n")
            widget.see(tk.END)
            widget.configure(state="disabled")

            if name == "ctrl":
                changed = True

    update_status_labels()

    if changed:
        draw_semaphores()

    root.after(200, drain_queues_to_widgets)

# ---------------- Semaphores ----------------
def draw_semaphores():
    veh_canvas.delete("all")
    veh_canvas.create_oval(8,8,62,62, fill=RED_COLOR if veh_state=="RED" else GRAY_COLOR)
    veh_canvas.create_oval(8,68,62,122, fill=AMBER_COLOR if veh_state=="AMBER" else GRAY_COLOR)
    veh_canvas.create_oval(8,128,62,182, fill=GREEN_COLOR if veh_state=="GREEN" else GRAY_COLOR)

    ped_canvas.delete("all")
    ped_canvas.create_oval(8,8,62,62, fill=RED_COLOR if ped_state=="RED" else GRAY_COLOR)
    ped_canvas.create_oval(8,68,62,122, fill=GREEN_COLOR if ped_state=="GREEN" else GRAY_COLOR)

# ---------------- Periodic GUI updates ----------------
def periodic_update():
    flags = []
    for path in [PED_FLAG_FILE, VEH_FLAG_FILE, ANIMAL_FLAG_FILE]:
        try:
            val = open(path).read().strip() if os.path.exists(path) else "-"
            flags.append(val if val in ("0","1") else "-")
        except:
            flags.append("-")

    flag_label.set(f"Ped:{flags[0]}   Veh:{flags[1]}   Animal:{flags[2]}")

    root.after(300, periodic_update)

def update_status_labels():
    def update(name, var):
        p = _processes.get(name)
        if p is None:
            var.set(f"{name.capitalize()}: detenido")
        elif p.poll() is None:
            var.set(f"{name.capitalize()}: ejecutándose (pid {p.pid})")
        else:
            var.set(f"{name.capitalize()}: salió (rc {p.returncode})")
            _processes[name] = None

    update("people", people_status_var)
    update("veh", veh_status_var)
    update("ctrl", ctrl_status_var)

# ---------------- Close event ----------------
def on_closing():
    if messagebox.askokcancel("Salir", "¿Detener todos los procesos y salir?"):
        stop_all_processes()
        time.sleep(0.5)
        root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

# ---------------- GUI Layout ----------------
control_frame = ttk.LabelFrame(root, text="Controles de Ejecución")
control_frame.pack(fill="x", padx=8, pady=6)

# buttons
individual_frame = ttk.Frame(control_frame)
individual_frame.pack(side="left")

ttk.Button(individual_frame, text="Start PeopleCam", command=start_people).pack(side="left", padx=4)
ttk.Button(individual_frame, text="Stop PeopleCam", command=lambda: stop_process("people")).pack(side="left", padx=4)
ttk.Button(individual_frame, text="Start VehCam", command=start_veh).pack(side="left", padx=4)
ttk.Button(individual_frame, text="Stop VehCam", command=lambda: stop_process("veh")).pack(side="left", padx=4)
ttk.Button(individual_frame, text="Start Controller", command=start_ctrl).pack(side="left", padx=4)
ttk.Button(individual_frame, text="Stop Controller", command=lambda: stop_process("ctrl")).pack(side="left", padx=4)

global_frame = ttk.Frame(control_frame)
global_frame.pack(side="right")
ttk.Button(global_frame, text="START ALL", command=start_all_processes, style='Accent.TButton').pack(side="left", padx=6)
ttk.Button(global_frame, text="STOP ALL", command=stop_all_processes).pack(side="left", padx=6)

# status
status_frame = ttk.Frame(root)
status_frame.pack(fill="x", padx=8)

people_status_var = tk.StringVar(value="PeopleCam: detenido")
veh_status_var = tk.StringVar(value="VehCam: detenido")
ctrl_status_var = tk.StringVar(value="Controller: detenido")

ttk.Label(status_frame, textvariable=people_status_var).pack(side="left", padx=8)
ttk.Label(status_frame, textvariable=veh_status_var).pack(side="left", padx=8)
ttk.Label(status_frame, textvariable=ctrl_status_var).pack(side="left", padx=8)

# logs
logs_frame = ttk.Frame(root)
logs_frame.pack(fill="both", expand=True, padx=8, pady=6)
logs_frame.columnconfigure(0, weight=1)
logs_frame.columnconfigure(1, weight=1)
logs_frame.columnconfigure(2, weight=1)

def make_log(frame, title):
    lf = ttk.LabelFrame(frame, text=title)
    lf.grid(sticky="nsew", padx=4, pady=4)
    log = scrolledtext.ScrolledText(lf, wrap="none", height=30)
    log.pack(fill="both", expand=True)
    log.configure(state="disabled")
    return log

people_log = make_log(logs_frame, "PeopleCam")
veh_log    = make_log(logs_frame, "VehCam")
ctrl_log   = make_log(logs_frame, "Controller")

logs_frame.children[list(logs_frame.children)[0]].grid(row=0, column=0, sticky="nsew")
logs_frame.children[list(logs_frame.children)[1]].grid(row=0, column=1, sticky="nsew")
logs_frame.children[list(logs_frame.children)[2]].grid(row=0, column=2, sticky="nsew")

# bottom
bottom_frame = ttk.Frame(root)
bottom_frame.pack(fill="x", padx=8, pady=6)

flag_label = tk.StringVar(value="Ped:-  Veh:-  Animal:-")
ttk.Label(bottom_frame, textvariable=flag_label, font=("Consolas", 12)).pack(side="left")

semaphores_frame = ttk.Frame(bottom_frame)
semaphores_frame.pack(side="right", padx=12)

veh_sem_frame = ttk.Frame(semaphores_frame)
veh_sem_frame.pack(side="right", padx=12)
ttk.Label(veh_sem_frame, text="Vehicular").pack(side="bottom")
veh_canvas = tk.Canvas(veh_sem_frame, width=70, height=180, bg="#2c3e50", highlightthickness=0)
veh_canvas.pack(side="top")

ped_sem_frame = ttk.Frame(semaphores_frame)
ped_sem_frame.pack(side="right", padx=12)
ttk.Label(ped_sem_frame, text="Peatonal").pack(side="bottom")
ped_canvas = tk.Canvas(ped_sem_frame, width=70, height=120, bg="#2c3e50", highlightthickness=0)
ped_canvas.pack(side="top")

# ---------------- INIT ----------------
root.after(200, drain_queues_to_widgets)
root.after(500, periodic_update)

help_text = (
    "Notas:\n"
    "- Las ventanas OpenCV las muestran los scripts.\n"
    "- La GUI captura logs de los procesos en tiempo real.\n"
    "- La salida del Controller actualiza los semáforos automáticamente.\n"
)
ttk.Label(root, text=help_text, justify="left").pack(side="bottom", fill="x", padx=8)

# warnings
if not os.path.exists(PEOPLE_SCRIPT):
    append_log("people", f"[GUI-INIT] WARNING: Script '{PEOPLE_SCRIPT}' no encontrado.")
if not os.path.exists(VEH_SCRIPT):
    append_log("veh", f"[GUI-INIT] WARNING: Script '{VEH_SCRIPT}' no encontrado.")
if not os.path.exists(CTRL_SCRIPT):
    append_log("ctrl", f"[GUI-INIT] WARNING: Script '{CTRL_SCRIPT}' no encontrado.")

root.mainloop()
