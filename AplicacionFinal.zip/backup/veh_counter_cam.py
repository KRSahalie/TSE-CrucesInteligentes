#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ==================================================================================================
#  VehCam (FlowGate-Smooth + Animal Flag) — Raspberry Pi + Yocto compatible
#
#  ✔ Compatible con YOLOv5n.onnx (coordenadas en pixeles 0–640)
#  ✔ Vehículos + animales
#  ✔ FlowGate + SmoothTracker
# ==================================================================================================

from __future__ import annotations
import os, cv2, time, json, argparse, math
import numpy as np

cv2.setUseOptimized(True)

# -------------------- Grupos de clases --------------------
ALLOWED_NAME_GROUPS = {
    "vehiculo": {"car","motorcycle","bus","truck","bicycle","train","van"},
    "animal":   {"dog","cat","bird","horse","sheep","cow","elephant","bear","zebra","giraffe"}
}

COLOR = {"vehiculo": (80,220,100), "animal": (60,180,255), None:(220,220,220)}

# -------------------- Utilidades --------------------
def center_in_mask(xyxy, mask_bin):
    if mask_bin is None: return True
    x1,y1,x2,y2 = map(int, xyxy)
    cx,cy = (x1+x2)//2, (y1+y2)//2
    h,w = mask_bin.shape[:2]
    return (0<=cx<w) and (0<=cy<h) and mask_bin[cy,cx] > 0

def draw_box(frame, xyxy, label=None, conf=None):
    x1,y1,x2,y2 = map(int, xyxy)
    color = COLOR.get(label, (220,220,220))
    cv2.rectangle(frame,(x1,y1),(x2,y2),color,2)
    txt=[]
    if label: txt.append(label)
    if conf is not None: txt.append(f"{conf:.2f}")
    if txt:
        t=" | ".join(txt)
        (tw,th),_=cv2.getTextSize(t,cv2.FONT_HERSHEY_SIMPLEX,0.5,1)
        cv2.rectangle(frame,(x1,y1-th-6),(x1+tw+6,y1),color,-1)
        cv2.putText(frame,t,(x1+3,y1-4),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,0,0),1)

# ==================================================================================================
#  YOLO ONNX — CORREGIDO PARA TU MODELO (PIXELS 0–640)
# ==================================================================================================
class YOLODetector:
    def __init__(self, model_path="yolov5n.onnx", conf=0.5, imgsz=640,
                 classes=None, nms_iou=0.60):

        self.net = cv2.dnn.readNetFromONNX(model_path)
        self.conf = conf
        self.imgsz = imgsz
        self.nms_iou = nms_iou
        self.allowed = set(c.lower() for c in classes)

        # COCO classes
        self.names = [
            "person","bicycle","car","motorcycle","airplane","bus","train","truck","boat",
            "traffic light","fire hydrant","stop sign","parking meter","bench","bird","cat","dog",
            "horse","sheep","cow","elephant","bear","zebra","giraffe","backpack","umbrella",
            "handbag","tie","suitcase","frisbee","skis","snowboard","sports ball","kite",
            "baseball bat","baseball glove","skateboard","surfboard","tennis racket","bottle",
            "wine glass","cup","fork","knife","spoon","bowl","banana","apple","sandwich","orange",
            "broccoli","carrot","hot dog","pizza","donut","cake","chair","couch","potted plant",
            "bed","dining table","toilet","tv","laptop","mouse","remote","keyboard","cell phone",
            "microwave","oven","toaster","sink","refrigerator","book","clock","vase","scissors",
            "teddy bear","hair drier","toothbrush"
        ]

    def infer(self, frame_bgr):
        H, W = frame_bgr.shape[:2]

        # YOLO blob
        blob = cv2.dnn.blobFromImage(
            frame_bgr, 1/255.0, (self.imgsz, self.imgsz),
            swapRB=True, crop=False
        )
        self.net.setInput(blob)

        # salida: (25200, 85)
        out = self.net.forward()[0]

        boxes = []
        names = []
        confs = []

        for det in out:
            obj_conf = det[4]
            cls_scores = det[5:]
            cls_id = int(np.argmax(cls_scores))
            cls_conf = cls_scores[cls_id]

            conf = float(obj_conf * cls_conf)
            if conf < self.conf:
                continue

            cls_name = self.names[cls_id].lower()
            if cls_name not in self.allowed:
                continue

            # coordenadas
            cx, cy, w, h = det[0], det[1], det[2], det[3]

            x1 = (cx - w/2) * (W / self.imgsz)
            y1 = (cy - h/2) * (H / self.imgsz)
            x2 = (cx + w/2) * (W / self.imgsz)
            y2 = (cy + h/2) * (H / self.imgsz)

            boxes.append([x1, y1, x2, y2])
            names.append(cls_name)
            confs.append(conf)

        # -------------------------
        # 🔥 NMS CORREGIDO
        # -------------------------
        if len(boxes) > 0:
            # convertir a formato [x, y, w, h]
            nms_boxes = []
            for b in boxes:
                x1, y1, x2, y2 = b
                nms_boxes.append([
                    x1,
                    y1,
                    x2 - x1,
                    y2 - y1
                ])

            idxs = cv2.dnn.NMSBoxes(
                nms_boxes, confs,
                self.conf, self.nms_iou
            )

            if len(idxs) > 0:
                idxs = idxs.flatten()
                boxes  = [boxes[i] for i in idxs]
                names  = [names[i] for i in idxs]
                confs  = [confs[i] for i in idxs]

        return boxes, names, confs





# ==================================================================================================
#  FlowGate — Optical Flow
# ==================================================================================================
class FlowGate:
    def __init__(self, thr_mag=2.5, thr_frac=0.18, down=2):
        self.prev_small=None
        self.thr_mag=thr_mag
        self.thr_frac=thr_frac
        self.down=down

    def update_and_check(self, gray, boxes, mask=None):
        if self.down>1:
            small=cv2.resize(gray,(gray.shape[1]//self.down, gray.shape[0]//self.down))
            mask_s=None if mask is None else cv2.resize(mask,(small.shape[1],small.shape[0]))
        else:
            small=gray
            mask_s=mask

        moving=[False]*len(boxes)

        if self.prev_small is None:
            self.prev_small = small.copy()
            return moving

        flow=cv2.calcOpticalFlowFarneback(
            self.prev_small, small, None,
            0.5,3,19,3,5,1.2,0
        )
        mag,_ = cv2.cartToPolar(flow[...,0], flow[...,1])

        H,W = small.shape[:2]

        for i,b in enumerate(boxes):
            x1,y1,x2,y2 = (v//self.down for v in map(int,b))
            x1=max(0,min(W-1,x1))
            x2=max(0,min(W,x2))
            y1=max(0,min(H-1,y1))
            y2=max(0,min(H,y2))
            if x2<=x1 or y2<=y1: continue

            roi = mag[y1:y2, x1:x2]
            if roi.size == 0: continue

            if mask_s is not None:
                m = mask_s[y1:y2, x1:x2]
                roi = roi[m>0]
                if roi.size == 0: continue

            moving[i] = (roi > self.thr_mag).sum() / roi.size >= self.thr_frac

        self.prev_small = small.copy()
        return moving

# ==================================================================================================
#  Tracker (Kalman + EMA)
# ==================================================================================================
class KalmanCV2D:
    def __init__(self,x,y,dt=1.0,q=1.2,r=6.0):
        self.x=np.array([[x],[y],[0],[0]],dtype=np.float32)
        self.P=np.eye(4,dtype=np.float32)*100
        self.q=q
        self.r=r
        self.last_t=time.time()
        self._set(dt)

    def _set(self,dt):
        dt=max(dt,1e-3)
        self.F=np.array([[1,0,dt,0],
                         [0,1,0,dt],
                         [0,0,1,0],
                         [0,0,0,1]],dtype=np.float32)
        self.H=np.array([[1,0,0,0],[0,1,0,0]],dtype=np.float32)

        self.Q=self.q*np.array([
            [dt**4/4,0,dt**3/2,0],
            [0,dt**4/4,0,dt**3/2],
            [dt**3/2,0,dt**2,0],
            [0,dt**3/2,0,dt**2]
        ],dtype=np.float32)

        self.R=np.eye(2,dtype=np.float32)*self.r

    def predict(self):
        t=time.time()
        dt=t-self.last_t
        self.last_t=t
        self._set(dt)
        self.x=self.F@self.x
        self.P=self.F@self.P@self.F.T + self.Q
        return float(self.x[0]), float(self.x[1])

    def update(self,zx,zy):
        z=np.array([[zx],[zy]],dtype=np.float32)
        y=z-(self.H@self.x)
        S=self.H@self.P@self.H.T + self.R
        K=self.P@self.H.T @ np.linalg.inv(S)
        self.x=self.x + K@y
        I=np.eye(4,dtype=np.float32)
        self.P=(I - K@self.H)@self.P

class SmoothTracker:
    def __init__(self,max_disappeared=25,max_distance=180,ema_alpha=0.35):
        self.next_id=1
        self.tracks={}
        self.max_disappeared=max_disappeared
        self.max_distance=max_distance
        self.alpha=ema_alpha

    @staticmethod
    def _centroid(b):
        x1,y1,x2,y2=b
        return (x1+x2)//2,(y1+y2)//2

    @staticmethod
    def _dist(a,b):
        return math.hypot(a[0]-b[0],a[1]-b[1])

    def update(self,boxes,moving):
        boxes=[list(map(int,b)) for b in boxes]
        det = [self._centroid(b) for b in boxes]

        preds={tid:tuple(map(int, tr["kf"].predict()))
               for tid,tr in self.tracks.items()}

        tids=list(self.tracks.keys())
        assigned=set()
        updates={}

        if preds and det:
            D=np.zeros((len(tids),len(det)),dtype=np.float32)
            for i,tid in enumerate(tids):
                for j,dc in enumerate(det):
                    D[i,j]=self._dist(preds[tid],dc)

            for _ in range(min(D.shape)):
                i,j=np.unravel_index(np.argmin(D),D.shape)
                if D[i,j] > self.max_distance: break
                tid=tids[i]
                updates[tid]=j
                assigned.add(j)
                D[i,:]=1e9; D[:,j]=1e9

        # update
        for tid,j in updates.items():
            cx,cy = det[j]
            tr = self.tracks[tid]
            tr["kf"].update(cx,cy)
            prev=np.array(tr["bbox"],float)
            curr=np.array(boxes[j],float)
            tr["bbox"] = list((self.alpha*curr + (1-self.alpha)*prev).astype(int))
            tr["flags"].append(moving[j])
            tr["disappear"]=0

        # new
        for j in range(len(boxes)):
            if j not in assigned:
                cx,cy = det[j]
                self.tracks[self.next_id] = {
                    "kf": KalmanCV2D(cx,cy),
                    "bbox": boxes[j],
                    "flags": [moving[j]],
                    "disappear": 0
                }
                self.next_id += 1

        # remove
        for tid in list(self.tracks.keys()):
            if tid not in updates:
                self.tracks[tid]["disappear"] += 1
                if self.tracks[tid]["disappear"] > self.max_disappeared:
                    self.tracks.pop(tid)

        return self.tracks, {tid:tr["bbox"] for tid,tr in self.tracks.items()}

    def moving_tracks_count(self,min_recent=5,ratio=0.7):
        c=0
        for tr in self.tracks.values():
            flags = tr["flags"][-min_recent:]
            if flags and (sum(flags)/len(flags)) >= ratio:
                c+=1
        return c

# ==================================================================================================
#  MAIN
# ==================================================================================================
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--src",required=True)
    ap.add_argument("--display",action="store_true")
    ap.add_argument("--width",type=int,default=1280)
    ap.add_argument("--height",type=int,default=720)
    ap.add_argument("--fps",type=int,default=30)

    ap.add_argument("--yolo_model",default="yolov5n.onnx")
    ap.add_argument("--veh_conf",type=float,default=0.20)
    ap.add_argument("--animal_conf",type=float,default=0.35)
    ap.add_argument("--det_every",type=int,default=3)

    ap.add_argument("--mask")
    ap.add_argument("--flow_thr",type=float,default=2.5)
    ap.add_argument("--flow_frac",type=float,default=0.18)
    ap.add_argument("--flow_down",type=int,default=2)

    ap.add_argument("--max_disappeared",type=int,default=25)
    ap.add_argument("--max_distance",type=float,default=180)
    ap.add_argument("--ema_alpha",type=float,default=0.35)

    ap.add_argument("--mov_min_recent",type=int,default=5)
    ap.add_argument("--mov_ratio",type=float,default=0.7)

    ap.add_argument("--write_count")
    ap.add_argument("--flag_out")
    ap.add_argument("--flag_threshold",type=int,default=4)

    ap.add_argument("--animal_flag_out")
    ap.add_argument("--animal_clear",type=int,default=6)
    ap.add_argument("--animal_classes")

    args=ap.parse_args()

    # ROI
    mask_bin=None
    if args.mask and os.path.exists(args.mask):
        m=cv2.imread(args.mask,cv2.IMREAD_GRAYSCALE)
        _,mask_bin=cv2.threshold(m,127,255,cv2.THRESH_BINARY)

    animal_set = (
        {s.strip() for s in args.animal_classes.split(",") if s.strip()}
        if args.animal_classes else ALLOWED_NAME_GROUPS["animal"]
    )
    classes = ALLOWED_NAME_GROUPS["vehiculo"] | animal_set

    # YOLO detector corregido
    yolo = YOLODetector(
        model_path=args.yolo_model,
        conf=min(args.veh_conf,args.animal_conf),
        imgsz=640,
        classes=classes,
        nms_iou=0.60
    )

    fgate = FlowGate(args.flow_thr,args.flow_frac,args.flow_down)
    tracker = SmoothTracker(args.max_disappeared,args.max_distance,args.ema_alpha)

    src = int(args.src) if args.src.isdigit() else args.src
    # ==============================================================
    #  RETRY: esperar a que la cámara USB inicialice
    #  (soluciona que la Nexigo no encienda al iniciar el servicio)
    # ==============================================================
    attempts = 12     # intenta durante ~10 segundos
    cap = None

    for i in range(attempts):
        cap = cv2.VideoCapture(src)

        # intenta fijar MJPG por si la cámara lo requiere
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        time.sleep(0.8)

        if cap.isOpened():
            print(f"[VehCam] Cámara abierta correctamente después de {i+1} intentos")
            break

    if not cap or not cap.isOpened():
        print("[VehCam] ERROR: No pude abrir cámara después de varios intentos")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT,args.height)
    cap.set(cv2.CAP_PROP_FPS,args.fps)

    if args.display:
        cv2.namedWindow("VehCam",cv2.WINDOW_NORMAL)

    last_flag = None
    frame_id = 0

    cache_boxes = []
    cache_names = []
    cache_confs = []

    animal_flag = 0
    cooldown = 0

    try:
        while True:
            ok,frame=cap.read()
            if not ok: break
            frame=cv2.resize(frame,(args.width,args.height))
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

            mask_r = None if mask_bin is None else cv2.resize(mask_bin,(args.width,args.height))

            # YOLO every N frames
            if frame_id % args.det_every == 0 or not cache_boxes:
                boxes,names,confs = yolo.infer(frame)
                cache_boxes,cache_names,cache_confs = boxes,names,confs
            else:
                boxes,names,confs = cache_boxes,cache_names,cache_confs

            # separar veh/animal
            veh_boxes=[]
            animal_boxes=[]
            for b,n,c in zip(boxes,names,confs):
                if not center_in_mask(b,mask_r): continue
                if n in ALLOWED_NAME_GROUPS["vehiculo"] and c>=args.veh_conf:
                    veh_boxes.append(b)
                elif n in animal_set and c>=args.animal_conf:
                    animal_boxes.append(b)

            # movimiento
            moving_flags = fgate.update_and_check(gray,veh_boxes,mask_r)
            moving_boxes = [b for b,m in zip(veh_boxes,moving_flags) if m]

            # tracking
            tracks,bboxes = tracker.update(moving_boxes, moving=[True]*len(moving_boxes))
            moving_count = tracker.moving_tracks_count(args.mov_min_recent,args.mov_ratio)

            # animal flag persistente
            if len(animal_boxes)>0:
                if animal_flag==0:
                    animal_flag=1
                    if args.animal_flag_out:
                        open(args.animal_flag_out,"w").write("1")
                cooldown = max(cooldown,args.animal_clear)
            else:
                if cooldown>0:
                    cooldown -= 1
                if cooldown==0 and animal_flag==1:
                    animal_flag=0
                    if args.animal_flag_out:
                        open(args.animal_flag_out,"w").write("0")

            # salida
            print(json.dumps({
                "ts":time.time(),
                "moving":moving_count,
                "animals":len(animal_boxes),
                "animal_flag":animal_flag
            }), flush=True)

            if args.write_count:
                open(args.write_count,"w").write(str(moving_count))

            if args.flag_out:
                f = 1 if moving_count>=args.flag_threshold else 0
                if f!=last_flag:
                    open(args.flag_out,"w").write(str(f))
                    last_flag = f

            # display
            if args.display:
                out = frame.copy()
                if mask_r is not None:
                    inv=cv2.bitwise_not(mask_r)
                    out[inv>0] = (out[inv>0]*0.25).astype(out.dtype)

                for bb in animal_boxes:
                    draw_box(out,bb,"animal")
                for tid,bb in bboxes.items():
                    draw_box(out,bb,"vehiculo")

                cv2.putText(out,f"Vehículos mov: {moving_count}",(12,32),
                            cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,0),3)
                cv2.putText(out,f"Vehículos mov: {moving_count}",(12,32),
                            cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),1)

                cv2.imshow("VehCam",out)
                if cv2.waitKey(1)&0xFF==ord('q'):
                    break

            frame_id+=1

    except KeyboardInterrupt:
        pass

    cap.release()
    if args.display:
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()

