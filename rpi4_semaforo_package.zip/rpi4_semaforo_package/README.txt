========================================
 Paquete RPi4 – Semáforo Inteligente
========================================

Este paquete contiene:

- Imagen Yocto para Raspberry Pi 4:
  - traffic-image-raspberrypi4.wic.bz2
  - traffic-image-raspberrypi4.wic.bmap

- Scripts de referencia (código fuente, NO necesarios para correr en la imagen Yocto):
  - ./scripts/people_counter_cam.py
  - ./scripts/veh_counter_cam.py
  - ./scripts/ScriptFinal_PreDeteccion.py
  - ./scripts/yolov8s.pt

- Archivos de comandos para copiar/pegar en la Raspberry Pi:
  - cmd_people_cam.txt   → detector de peatones (cámara 0)
  - cmd_veh_cam.txt      → detector de vehículos/animales (cámara 1)
  - cmd_semaforo.txt     → lógica del semáforo


1. Grabado de la imagen en la SD (Linux)
----------------------------------------

1) Identificar el dispositivo de la SD:

   lsblk

2) Grabar la imagen (reemplazar /dev/sdX por el dispositivo correcto, por ejemplo /dev/sdb):

   bzcat traffic-image-raspberrypi4.wic.bz2 | sudo dd of=/dev/sdX bs=4M status=progress conv=fsync

Opcional (si se usa bmaptool):

   sudo bmaptool copy traffic-image-raspberrypi4.wic.bz2 /dev/sdX


2. Uso de los archivos de comandos (cmd_*.txt)
----------------------------------------------

En la Raspberry Pi, después de arrancar con la SD:

- Abrir los archivos:
  - cmd_people_cam.txt
  - cmd_veh_cam.txt
  - cmd_semaforo.txt

Cada archivo contiene los comandos listos para ejecutar.
La idea es:

1) Abrir una terminal, copiar el contenido de cmd_people_cam.txt y pegarlo.
2) Abrir otra terminal, copiar el contenido de cmd_veh_cam.txt y pegarlo.
3) Abrir una tercera terminal, copiar el contenido de cmd_semaforo.txt y pegarlo.


3. Comandos que ejecuta cada cmd_*.txt
--------------------------------------


3.1. Detector de peatones (cámara 0) – cmd_people_cam.txt
----------------------------------------------------------

   cd /opt/traffic-ai
   python3 people_counter_cam.py \
     --src 0 \
     --display \
     --width 1280 --height 720 \
     --yolo_model /opt/traffic-ai/models/yolov8s.pt \
     --write_count /tmp/ped_count.txt \
     --flag_out /tmp/ped_flag.txt \
     --flag_threshold 3

Este proceso:

- Usa la cámara 0 para detectar peatones en el cruce.
- Escribe:
  - /tmp/ped_count.txt : cantidad de peatones detectados
  - /tmp/ped_flag.txt  : 1 si hay >= 3 peatones, 0 en caso contrario


3.2. Detector de vehículos/animales (cámara 1) – cmd_veh_cam.txt
----------------------------------------------------------------

   cd /opt/traffic-ai
   python3 veh_counter_cam.py \
     --src 1 \
     --display \
     --width 1280 --height 720 \
     --yolo_model /opt/traffic-ai/models/yolov8s.pt \
     --animal_flag_out /tmp/animal_flag.txt \
     --write_count /tmp/veh_moving.txt \
     --flag_out /tmp/veh_flag.txt \
     --flag_threshold 4 \
     --flow_thr 2.5 \
     --flow_frac 0.18 \
     --mov_min_recent 5 \
     --mov_ratio 0.7

Este proceso:

- Usa la cámara 1 para detectar vehículos en movimiento y animales en la vía.
- Escribe:
  - /tmp/animal_flag.txt : 1 si hay animal en la zona, 0 cuando se despeja
  - /tmp/veh_moving.txt  : cantidad de vehículos en movimiento (informativo)
  - /tmp/veh_flag.txt    : 1 si hay muchos vehículos moviéndose (opcional)


3.3. Lógica de semáforo – cmd_semaforo.txt
------------------------------------------

   cd /opt/traffic-ai
   python3 ScriptFinal_PreDeteccion.py

Este proceso:

- Lee los flags generados por los detectores:
  - /tmp/ped_flag.txt
  - /tmp/animal_flag.txt
- Mantiene el semáforo de vehículos en VERDE mientras:
  - no haya suficientes peatones (ped_flag = 0)
  - no haya animal en vía (animal_flag = 0)
- Cuando ped_flag pasa a 1:
  - cambia a ROJO vehículos / VERDE peatones durante una ventana controlada
  - utiliza un cooldown para no cambiar demasiado rápido si siguen llegando peatones
- Cuando animal_flag pasa a 1:
  - fuerza un estado de seguridad (ROJO para vehículos) mientras dure la condición


4. Archivos temporales usados por el sistema (/tmp)
---------------------------------------------------

Los siguientes archivos se crean y actualizan automáticamente en la Raspberry Pi mientras corren los scripts:

- /tmp/ped_count.txt   : cantidad de peatones detectados
- /tmp/ped_flag.txt    : 1 si hay >= 3 peatones, 0 en caso contrario
- /tmp/animal_flag.txt : 1 si hay animal en vía, 0 cuando se despeja
- /tmp/veh_moving.txt  : cantidad de vehículos en movimiento (informativo)
- /tmp/veh_flag.txt    : 1 si hay muchos vehículos moviéndose (opcional)

NOTAS:

- Estos archivos NO están en el paquete; se generan en tiempo de ejecución.
- /tmp suele limpiarse al reiniciar el sistema, por lo que se recrean cuando se vuelven a lanzar los detectores.


5. Referencia: scripts incluidos en la carpeta "scripts/"
---------------------------------------------------------

Dentro de ./scripts/ se incluyen copias de referencia de:

- people_counter_cam.py
- veh_counter_cam.py
- ScriptFinal_PreDeteccion.py
- yolov8s.pt

La imagen Yocto ya instala versiones de estos archivos en:

- /opt/traffic-ai/people_counter_cam.py
- /opt/traffic-ai/veh_counter_cam.py
- /opt/traffic-ai/ScriptFinal_PreDeteccion.py
- /opt/traffic-ai/models/yolov8s.pt

Los scripts de ./scripts/ son solo para revisión de código o pruebas fuera del entorno Yocto.
